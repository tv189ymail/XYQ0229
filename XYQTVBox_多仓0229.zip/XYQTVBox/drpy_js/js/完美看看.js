muban.首图2.二级.tabs = '.stui-pannel__head&&h3';
var rule = Object.assign(muban.首图2,{
title:'完美看看',
host:'https://www.wanmeikk.film',
class_parse:'.dropdown&&li;a&&Text;a&&href;.*/(.*?).html',
cate_exclude:'消息|专题',
url:'/category/fyclass-fypage.html',
searchUrl:'/so/-------------.html?wd=**&submit=',
});